

function XYZW_tens=scale_rule(XYZW_tens_ref,dbox)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% Scale reference nodes from [-1,1]^3 to the bounding box.
%
% Note:
% For the needs of the routine it is not required to scale also the
% weights.
%-----------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%----------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 26, 2025
%--------------------------------------------------------------------------

a=dbox(1); b=dbox(2);
X=XYZW_tens_ref(:,1);
X=(a+b)/2 + ((b-a)/2)*X;

a=dbox(3); b=dbox(4);
Y=XYZW_tens_ref(:,2);
Y=(a+b)/2 + ((b-a)/2)*Y;

a=dbox(5); b=dbox(6);
Z=XYZW_tens_ref(:,3);
Z=(a+b)/2 + ((b-a)/2)*Z;

W=XYZW_tens_ref(:,4);

XYZW_tens=[X Y Z W];