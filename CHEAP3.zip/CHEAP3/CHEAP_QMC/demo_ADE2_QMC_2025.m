
function demo_ADE2_QMC_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows numerically how the cheap rules have the desired
% algebraic degree of exactness (w.r.t. QMC discrete measure).
%
% For the degrees "adeV" and a QMC rule in a bounding box of the domain,
% based on "card" QMC points, it computes the cheap rule of degree "n", and
% evaluates "number_tests" examples of polynomial integrands with degree
% "n".
%
% As result, it plots a figure displaying the relative errors and its
% average exponent.
%
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires from about 
% * 45s for domain 1;
% * 25s for domain 2.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete 
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> % Examples setting "domain=1".
% >> demo_ADE2_QMC_2025
%
% ade:  2 card QMC:  23076 CH:     27 ratios: 1.170e-03
% ade:  2 [log re] QMC/ref: 5.940e-04 CH/REF: 5.940e-04 QMC/CH: 1.314e-14
%
% ade:  4 card QMC:  23076 CH:    125 ratios: 5.417e-03
% ade:  4 [log re] QMC/ref: 7.499e-04 CH/REF: 7.499e-04 QMC/CH: 2.264e-14
%
% ade:  6 card QMC:  23076 CH:    343 ratios: 1.486e-02
% ade:  6 [log re] QMC/ref: 6.079e-04 CH/REF: 6.079e-04 QMC/CH: 4.335e-14
%
% ade:  8 card QMC:  23076 CH:    729 ratios: 3.159e-02
% ade:  8 [log re] QMC/ref: 6.772e-04 CH/REF: 6.772e-04 QMC/CH: 2.593e-13
%
% ade: 10 card QMC:  23076 CH:   1331 ratios: 5.768e-02
% ade: 10 [log re] QMC/ref: 6.286e-04 CH/REF: 6.286e-04 QMC/CH: 4.652e-13
%
% ade: 12 card QMC:  23076 CH:   2197 ratios: 9.521e-02
% ade: 12 [log re] QMC/ref: 7.125e-04 CH/REF: 7.125e-04 QMC/CH: 9.455e-13
%
% ade: 14 card QMC:  23076 CH:   3375 ratios: 1.463e-01
% ade: 14 [log re] QMC/ref: 1.063e-03 CH/REF: 1.063e-03 QMC/CH: 1.500e-12
%
% ade: 16 card QMC:  23076 CH:   4913 ratios: 2.129e-01
% ade: 16 [log re] QMC/ref: 1.046e-03 CH/REF: 1.046e-03 QMC/CH: 3.368e-12
%
% ......................................................
% card ratios: card_CH / card_QMC;
% see figure with relative errors
% ......................................................
%
% >> % Examples setting "domain=2".
% >> demo_ADE2_QMC_2025
% 
% ade:  2 card QMC:  37379 CH:     27 ratios: 7.223e-04 
% ade:  2 [log re] QMC/ref: 1.533e-03 CH/REF: 1.533e-03 QMC/CH: 3.314e-14 
% 
% ade:  4 card QMC:  37379 CH:    125 ratios: 3.344e-03 
% ade:  4 [log re] QMC/ref: 1.977e-03 CH/REF: 1.977e-03 QMC/CH: 5.312e-14 
% 
% ade:  6 card QMC:  37379 CH:    343 ratios: 9.176e-03 
% ade:  6 [log re] QMC/ref: 2.305e-03 CH/REF: 2.305e-03 QMC/CH: 8.851e-14 
% 
% ade:  8 card QMC:  37379 CH:    729 ratios: 1.950e-02 
% ade:  8 [log re] QMC/ref: 2.773e-03 CH/REF: 2.773e-03 QMC/CH: 4.860e-13 
% 
% ade: 10 card QMC:  37379 CH:   1331 ratios: 3.561e-02 
% ade: 10 [log re] QMC/ref: 2.635e-03 CH/REF: 2.635e-03 QMC/CH: 7.207e-13 
% 
% ade: 12 card QMC:  37379 CH:   2197 ratios: 5.878e-02 
% ade: 12 [log re] QMC/ref: 3.400e-03 CH/REF: 3.400e-03 QMC/CH: 1.422e-12 
% 
% ade: 14 card QMC:  37379 CH:   3375 ratios: 9.029e-02 
% ade: 14 [log re] QMC/ref: 3.163e-03 CH/REF: 3.163e-03 QMC/CH: 2.677e-12 
% 
% ade: 16 card QMC:  37379 CH:   4913 ratios: 1.314e-01 
% ade: 16 [log re] QMC/ref: 2.941e-03 CH/REF: 2.941e-03 QMC/CH: 6.149e-12 
% 
% ...................................................... 
% card ratios: card_CH / card_QMC;
% see figure with relative errors
% ...................................................... 
% >> 
%--------------------------------------------------------------------------
% Modified object (Oct. 21, 2025)
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 25, 2025
%--------------------------------------------------------------------------

clf; clear all;

domain=2; % Define domain depending on this variable.
card_ref=10^6; % QMC cardinality (ref.results).
card=10^5; % QMC cardinality (QMC in tests).
adeV=2:2:16; % Degree of precision of the rule.
number_tests=100; % Polynomial tests.

% ........................ main code below ............................

% QMC points reference rule
[pts_QMC_ref,w_QMC_ref,dbox]=provide_domain_QMC(domain,card_ref);

% QMC initial rule
[pts_QMC,w_QMC,dbox]=provide_domain_QMC(domain,card);

for ii=1:length(adeV)

    ade=adeV(ii);


    % .................... A. QMC cheap startup ...........................

    [XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);


    % .................... B. QMC cheap rule ..............................
    dboxV=dbox'; dboxV=dboxV(:);
    moments_ch=cubature_tens_chebyshev_QMC(pts_QMC,w_QMC,...
        chebyshev_indices,dboxV);

    XYZW_tens=scale_rule(XYZW_tens_ref,dboxV);
    w1=XYZW_tens(:,4);
    w2=V_ref*(moments_ch./coeffs);

    W=w1.*w2;

    XYZW=[XYZW_tens(:,1:3) W];

    cardL_QMC=length(w_QMC); cardL_CH=length(W); rat=cardL_CH/cardL_QMC;

    fprintf(' \n \t ade: %2.0f card QMC: %6.0f CH: %6.0f ratios: %1.3e ',...
        ade,cardL_QMC,cardL_CH,rat);



    % .................... C. Tests over random polynomials ...............

    for jj=1:number_tests
        % Random polynomial integrand of degree "n"
        k1=rand(1); k2=rand(1); k3=rand(1); c1=rand(1);
        f=@(x,y,z) (c1+k1*x+k2*y+k3*z).^ade;

        % ............. reference result ............
        f_pts_QMC_ref=feval(f,pts_QMC_ref(:,1),pts_QMC_ref(:,2),...
            pts_QMC_ref(:,3));
        I_exact =w_QMC_ref'*f_pts_QMC_ref;

        f_pts_QMC=feval(f,pts_QMC(:,1),pts_QMC(:,2),pts_QMC(:,3));
        I_QMC =w_QMC'*f_pts_QMC;

        I_ch=W'*feval(f,XYZW(:,1),XYZW(:,2),XYZW(:,3));

        % ... Absolute/Relative errors ...

        % QMC vs QMC ref
        aeV_QMC(jj)=abs(I_exact-I_QMC);

        if abs(I_exact) > 10^(-6) | abs(I_exact) < 10^(+12)
            reV_QMC(jj)=aeV_QMC(jj)/abs(I_exact);
        else
            reV_QMC(jj)=0;
        end

        % cheap vs QMC ref
        aeV_CH(jj)=abs(I_exact-I_ch);

        if abs(I_exact) > 10^(-6) | abs(I_exact) < 10^(+12)
            reV_CH(jj)=aeV_CH(jj)/abs(I_exact);
        else
            reV_CH(jj)=0;
        end

        % cheap vs QMC
        aeV_CH_QMC(jj)=abs(I_QMC-I_ch);

        if abs(I_exact) > 10^(-6) | abs(I_exact) < 10^(+12)
            reV_CH_QMC(jj)=aeV_CH_QMC(jj)/abs(I_exact);
        else
            reV_CH_QMC(jj)=0;
        end

    end


    % ....................... D. Statistics ...............................

    % average errors (needs log!)

    % QMC vs QMC ref
    iok1=find(aeV_QMC > 0);
    log_aeV_QMC(ii)=10^(mean(log10(aeV_QMC(iok1))));

    iok2=find(reV_QMC > 0);
    log_reV_QMC(ii)=10^(mean(log10(reV_QMC(iok2))));

    % cheap vs QMC ref
    iok1=find(aeV_CH > 0);
    log_aeV_CH(ii)=10^(mean(log10(aeV_CH(iok1))));

    iok2=find(reV_CH > 0);
    log_reV_CH(ii)=10^(mean(log10(reV_CH(iok2))));

    % cheap vs QMC
    iok1=find(aeV_CH_QMC > 0);
    log_aeV_CH_QMC(ii)=10^(mean(log10(aeV_CH_QMC(iok1))));

    iok2=find(reV_CH_QMC > 0);
    log_reV_CH_QMC(ii)=10^(mean(log10(reV_CH_QMC(iok2))));



    fprintf('\n \t ade: %2.0f [log re] QMC/ref: %1.3e CH/REF: %1.3e QMC/CH: %1.3e \n',...
        ade,log_reV_QMC(ii),log_reV_CH(ii),log_reV_CH_QMC(ii))

    % plots

    plot_errors(ii,adeV,reV_CH_QMC,log_reV_CH_QMC(ii));
    hold on;

end

hold off;



fprintf('\n \t ......................................................');
fprintf('\n \t card ratios: card_CH / card_QMC;');
fprintf('\n \t see figure with relative errors');
fprintf('\n \t ...................................................... \n');


















%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,adeV,reV,log_re)

n=adeV(ii);

xmin=min(adeV)-1;
xmax=max(adeV)+1;
xlim([xmin xmax]);

ax = gca;

ax.XAxis.FontSize = 12;
ax.YAxis.FontSize = 12;

set(gca,'XTickLabel',{adeV})
C=colororder("glow12");

if ii <= 12
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',C(ii,:)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
end


