
function [XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade)

%--------------------------------------------------------------------------
% Object.
%--------------------------------------------------------------------------
% The cheap algorithm requires a startup that can be used for rules over
% 3D domains. 
%
% The variables computed here are independent from the polyhedra and can be
% computed and even stored for computing rules with degree of exactness
% "ade" on any polyhedra.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% A new computational paradigm for low-cost discretized measure compression
% by L. Rinaldi, A. Sommariva, M. Vianello.
% Modified object (Oct. 21, 2025)
%--------------------------------------------------------------------------
% Authors: Laura Rinaldi, Alvise Sommariva*, Marco Vianello.
%--------------------------------------------------------------------------

% A. compute moments
XYZW_tens_ref=cub_gausscheb_tens3D(2*ade);

% B. compute basis indices (tens. cheb. basis ordering)
d=3; N = nchoosek(ade+d,d); chebyshev_indices = zeros(N,3);
for i=2:N
    chebyshev_indices(i,:) = mono_next_grlex(d,chebyshev_indices(i-1,:));
end

% C. reference Vandermonde matrix
X=XYZW_tens_ref(:,1:3);
V_ref = dCHEBVAND(ade,X,[-1 -1 -1; 1 1 1],chebyshev_indices);

% D. scalar products of basis elements.
[coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,chebyshev_indices);