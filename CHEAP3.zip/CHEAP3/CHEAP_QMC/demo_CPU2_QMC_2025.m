
function demo_CPU2_QMC_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows numerically the CPUTIMES of the rules (Cheap/QMC).
% Depending on the domain (i.e. the domain choosen in a list), it
% 1. computes a QMC rule on the domain D, based on points on a bounding box
%    B of D.
% 2. Varying the choosen degree "ade" in "adeV" it computes cheap rules in
%    B of degree "ade".
% 3. Lists the cputimes of the process, as well as the cardinality of the
%    cheap rule.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about 
% * 90 seconds for domain 1;
% * 90 seconds for domain 2.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete 
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Last modification: 19 October 2025
% 1. card set to 10^5
% 2. added cputimes to QMC (lines 24-29)
% 3. added tic (line 55)
%--------------------------------------------------------------------------
% Example
%--------------------------------------------------------------------------
% >> % setting "domain=1"
% >> demo_CPU_QMC_2025
%
% .......... Settings/Info  ..........
%
% domain: 1
% cardinality QMC rule (bbox)   :  100000
% cardinality QMC rule (domain) :   23076
%
% ........ Cardinalities  ............
%
% | ade |  cheap   |
% ...................
%    2    &  3e+01
%    4    &  1e+02
%    6    &  3e+02
%    8    &  7e+02
%   10    &  1e+03
%   12    &  2e+03
%   14    &  3e+03
%   16    &  5e+03
%
% ........ Cputimes .................
%
% QMC cputime: 1.34136e+00 
%
% | ade |  cheap   |
% ...................
%   2   &  3e-03
%   4   &  9e-03
%   6   &  2e-02
%   8   &  3e-02
%  10   &  6e-02
%  12   &  9e-02
%  14   &  1e-01
%  16   &  2e-01
%
% >> % setting "domain=2"
% >> demo_CPU_QMC_2025
% .......... Settings/Info  ..........
%
% domain: 2
% cardinality QMC rule (bbox)   :  100000
% cardinality QMC rule (domain) :   37379
%
% ........ Cardinalities  ............
%
% | ade |  cheap   |
% ...................
%    2    &  27
%    4    &  125
%    6    &  343
%    8    &  729
%   10    &  1331
%   12    &  2197
%   14    &  3375
%   16    &  4913
%
% ........ Cputimes .................
%
% QMC cputime: 1.07814e-01 
%
% | ade |  cheap   |
% ...................
%   2   &  5e-03
%   4   &  1e-02
%   6   &  3e-02
%   8   &  5e-02
%  10   &  9e-02
%  12   &  1e-01
%  14   &  2e-01
%  16   &  3e-01
%
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) Core(TM) Ultra 5 125H   
% 3.60 GHz with 16 GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 25, 2025
%--------------------------------------------------------------------------

clf; clear all;

domain=2;         % Define domain depending on this variable.
card=10^5;        % QMC cardinality.

adeV=2:2:16;      % Degree of precision of the ch. rule (wrt QMC measure).
number_tests=100; % Number of experiments.

% ........................ main code below ................................

% A. QMC measure.
number_tests_QMC=10;
for k=1:number_tests_QMC
    tic;
    [pts_QMC,w_QMC,dbox]=provide_domain_QMC(domain,card);
    cpu_QMC(k)=toc;
end
log_aver_cpu_QMC=10^(mean(log10(cpu_QMC)));

% B. CHEAP experiments
cpus=[];
card_ch=[];

for ii=1:length(adeV)

    ade=adeV(ii);

    for k=1:number_tests

        % A. Cheap routine.

        % .................... A. QMC cheap startup .......................

        [XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);


        % .................... B. QMC cheap rule ..........................

        dboxV=dbox'; dboxV=dboxV(:);
        tic;
        moments_ch=cubature_tens_chebyshev_QMC(pts_QMC,w_QMC,...
            chebyshev_indices,dboxV);

        XYZW_tens=scale_rule(XYZW_tens_ref,dboxV);
        w1=XYZW_tens(:,4); w2=V_ref*(moments_ch./coeffs);
        W=w1.*w2;

        XYZW=[XYZW_tens(:,1:3) W];

        cpusL1(k)=toc;
    end

    % average cputime
    log_aver_cpu(ii,1)=10^(mean(log10(cpusL1)));


    card_ch=[card_ch; length(W)];
    cpus=[cpus; log_aver_cpu];

end




% C. Statistics
fprintf('\n \n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t domain: %1.0f',domain);
fprintf('\n \t cardinality QMC rule (bbox)   : %7.0f',card);
fprintf('\n \t cardinality QMC rule (domain) : %7.0f',length(w_QMC));

fprintf('\n \n \t ........ Cardinalities  ............ \n ')
fprintf('\n \t | ade |  cheap   | ')
fprintf('\n \t ...................')
for k=1:length(adeV)
    fprintf('\n \t   %2.0f    &  %-6.0f ',adeV(k),card_ch(k));
end

fprintf('\n \n \t ........ Cputimes ................. \n ')

fprintf('\n \t QMC cputime: %1.5e \n',log_aver_cpu_QMC);

fprintf('\n \t | ade |  cheap   | ')
fprintf('\n \t ...................')

for k=1:length(adeV)
    fprintf('\n \t  %2.0f   &  %1.0e ',adeV(k),log_aver_cpu(k,1));
end

fprintf('\n \n');

