
function demo_SUMWEIGHTS_QMC_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the sum of weights of the QMC cheap rule in some domains.
% In particular,
% 1. computes QMC rule on a test domain (starting from "card" Halton points
%    in a bounding box of the integration domain.
% 2. computes a cheap rule of degree "ade".
% 3. computes sum of weights as well as the sum of their absolute values.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about
% *  5 seconds for domain 1;
% *  3 seconds for domain 2.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> % setting "domain=1"
% >> demo_SUMWEIGHTS_QMC_2025
%
% .......... Settings/Info  ..........
%
% domain: 1
% ade cheap                     : 16
% cardinality cheap rule        : 4913
% cardinality QMC rule (bbox)   : 100000
% cardinality QMC rule (domain) : 23076
% ...............................................
%
% | ade |   sum(W)   |  abs(sum(W)) |  ratio |
% ...............................................
%   2   &  2.020e-01 &  3.119e-01 & 1.54e+00
%   4   &  2.020e-01 &  3.559e-01 & 1.76e+00
%   6   &  2.020e-01 &  3.173e-01 & 1.57e+00
%   8   &  2.020e-01 &  2.749e-01 & 1.36e+00
%  10   &  2.020e-01 &  2.625e-01 & 1.30e+00
%  12   &  2.020e-01 &  2.601e-01 & 1.29e+00
%  14   &  2.020e-01 &  2.548e-01 & 1.26e+00
%  16   &  2.020e-01 &  2.494e-01 & 1.23e+00
% ...............................................
%
% >> % setting "domain=2"
% >> demo_SUMWEIGHTS_QMC_2025
%
% .......... Settings/Info  ..........
%
% domain: 2
% ade cheap                     : 16
% cardinality cheap rule        : 4913
% cardinality QMC rule (bbox)   : 100000
% cardinality QMC rule (domain) : 37379
% ...............................................
%
% | ade |   sum(W)   |  abs(sum(W)) |  ratio |
% ...............................................
%   2   &  1.962e+00 &  2.978e+00 & 1.52e+00
%   4   &  1.962e+00 &  2.838e+00 & 1.45e+00
%   6   &  1.962e+00 &  2.514e+00 & 1.28e+00
%   8   &  1.962e+00 &  2.510e+00 & 1.28e+00
%  10   &  1.962e+00 &  2.379e+00 & 1.21e+00
%  12   &  1.962e+00 &  2.324e+00 & 1.18e+00
%  14   &  1.962e+00 &  2.328e+00 & 1.19e+00
%  16   &  1.962e+00 &  2.282e+00 & 1.16e+00
% ...............................................
%
%  >>
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------

clear all;

domain=1; % Define domain depending on this variable.
card=10^5; % QMC cardinality.
adeV=2:2:16;    % Degree of precision of the rule.

% ........................ main code below ................................

[pts_QMC,w_QMC,dbox]=provide_domain_QMC(domain,card);


% ...... Perform Cheap tests ......

sum_W=[];
sum_absW=[];

for ade=adeV

    % .................... A. QMC cheap startup ...........................
    [XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);


    % .................... B. QMC cheap rule ..............................
    dboxV=dbox'; dboxV=dboxV(:);
    moments_ch=cubature_tens_chebyshev_QMC(pts_QMC,w_QMC,...
        chebyshev_indices,dboxV);

    XYZW_tens=scale_rule(XYZW_tens_ref,dboxV);
    w1=XYZW_tens(:,4);
    w2=V_ref*(moments_ch./coeffs);

    W=w1.*w2;

    sum_W=[sum_W; sum(W)];
    sum_absW=[sum_absW; (sum(abs(W)))];

end

% ....................... D. Statistics ................................

fprintf('\n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t domain: %1.0f',domain);
fprintf('\n \t ade cheap                     : %-7.0f',ade);
fprintf('\n \t cardinality cheap rule        : %-7.0f',length(W));
fprintf('\n \t cardinality QMC rule (bbox)   : %-7.0f',card);
fprintf('\n \t cardinality QMC rule (domain) : %-7.0f',length(w_QMC));



fprintf('\n \t ...............................................   ')

fprintf('\n \n \t | ade |   sum(W)   |  abs(sum(W)) |  ratio |')
fprintf('\n \t ...............................................   ')

for k=1:length(adeV)
    fprintf('\n \t  %2.0f   &  %1.3e &  %1.3e & %1.2e',adeV(k),sum_W(k),...
        sum_absW(k),sum_absW(k)/sum_W(k));
end


fprintf('\n \t ...............................................   \n \n')