
function [pts_QMC,w_QMC,dbox]=provide_domain_QMC(example,card)

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This routine, depending on the example, defines the domain "D" as 
% specified by the variable "example". 
% 
% Random nodes of cardinality "card" are defined on a bounding box of the 
% domain, so determining, by in-domain functions, a QMC rule on the domain 
% D.
% 
% The rule has nodes the N x 3 matrix "pts_QMC", as weights the N x 1
% matrix w_QMC, and in the 2 x 3 matrix "dbox" it represents the bounding 
% box of the domain (first row are the left x,y,z extrema, the second row 
% consist of the right x,y,z extrema).
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Modified object (Oct. 21, 2025).
% Cut attached routines (inball, provide_vertices).
% Modified object attached routine.
% Cut string about printing fprintf('\n \t Example 2').
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------

switch example

    case 1 % intersection polyhedron/ball

        % ............................ Ball ...............................

        center=[0 0 0]; radius=1;

        dbox_ball_X=[center(1)- radius center(1)+radius];
        dbox_ball_Y=[center(2)- radius center(2)+radius];
        dbox_ball_Z=[center(3)- radius center(3)+radius];

        %  ........................ Polyhedron  ...........................

        example_polyhedron=1;
        [vertices,polyhedron_type,alphashape_radius]=provide_vertices(...
            example_polyhedron);

        % Facets of the polyhedron.
        X=vertices(:,1); Y=vertices(:,2); Z=vertices(:,3);

        % Determining facets and triangulation.
        tri_method=1;
        switch tri_method

            case 1
                % Using alphashape
                SHP = alphaShape(X,Y,Z,alphashape_radius);
                facets = boundaryFacets(SHP);
                % tri = alphaTriangulation(SHP);

            case 2
                % Using convhull
                facets = convhull(X,Y,Z);
                % tri = delaunay(X,Y,Z);

        end

        fv.vertices=vertices; fv.faces=facets;

        dbox_polyhedron_X=[min(X) max(X)];
        dbox_polyhedron_Y=[min(Y) max(Y)];
        dbox_polyhedron_Z=[min(Z) max(Z)];

        % ................... 3. bounding box intersection ................

        dbox_X=[max(dbox_ball_X(1),dbox_polyhedron_X(1)) ...
            min(dbox_ball_X(2),dbox_polyhedron_X(2))];

        dbox_Y=[max(dbox_ball_Y(1),dbox_polyhedron_Y(1)) ...
            min(dbox_ball_Y(2),dbox_polyhedron_Y(2))];

        dbox_Z=[max(dbox_ball_Z(1),dbox_polyhedron_Z(1)) ...
            min(dbox_ball_Z(2),dbox_polyhedron_Z(2))];

        dbox=[dbox_X; dbox_Y; dbox_Z];

        % ......................... 4. QMC rule ...........................

        p=haltonset(3);

        % PP=[0.51    0.26    0.63]; ip = inpolyhedron(fv, PP)
        % pause

        pts_ud_ref=p(1:card,:);

        pts_ud_bb(:,1)=dbox_X(1,1)+diff(dbox_X)*pts_ud_ref(:,1);
        pts_ud_bb(:,2)=dbox_Y(1,1)+diff(dbox_Y)*pts_ud_ref(:,2);
        pts_ud_bb(:,3)=dbox_Z(1,1)+diff(dbox_Z)*pts_ud_ref(:,3);

        % inside polyhedron

        ip = inpolyhedron(fv, pts_ud_bb);
        ind2=(ip==1);
        pts_ud_2=pts_ud_bb(ind2,:);

        % inside cylinder
        pts_QMC=inball(pts_ud_2,center,radius);
        card_int=size(pts_QMC,1);

        % QMC weights
        vol_bb=(diff(dbox_X))*(diff(dbox_Y))*(diff(dbox_Z));
        w_QMC=(vol_bb/card)*ones(card_int,1);


    case 2 % union of balls

        % definition of the domain

        card_centers=5;

        p2=haltonset(3);
        centers=p2(1:card_centers,:);

        p=haltonset(1);
        radii=0.5*ones(card_centers,1);

        xmin=centers(:,1)-radii; xmax=centers(:,1)+radii;
        ymin=centers(:,2)-radii; ymax=centers(:,2)+radii;
        zmin=centers(:,3)-radii; zmax=centers(:,3)+radii;

        % bounding box

        dbox_X=[min(xmin) max(xmax)];
        dbox_Y=[min(ymin) max(ymax)];
        dbox_Z=[min(zmin) max(zmax)];

        dbox=[dbox_X; dbox_Y; dbox_Z];

        p=haltonset(3);
        pts_ud_ref=p(1:card,:);

        pts_ud_bb(:,1)=dbox_X(1,1)+diff(dbox_X)*pts_ud_ref(:,1);
        pts_ud_bb(:,2)=dbox_Y(1,1)+diff(dbox_Y)*pts_ud_ref(:,2);
        pts_ud_bb(:,3)=dbox_Z(1,1)+diff(dbox_Z)*pts_ud_ref(:,3);

        % finding Halton points in unions of balls.

        for k=1:card
            in(k)=0;
            pts=pts_ud_bb(k,:);
            dist_centers=sqrt( (centers(:,1)-pts(1)).^2 + ...
                (centers(:,2)-pts(2)).^2 + (centers(:,3)-pts(3)).^2 );
            index=( dist_centers <= radii );
            ip(k)=(sum(index) > 0);
        end

        ind2=(ip==1);
        pts_QMC=pts_ud_bb(ind2,:);
        
        card_int=size(pts_QMC,1);

        % QMC weights
        vol_bb=(diff(dbox_X))*(diff(dbox_Y))*(diff(dbox_Z));
        w_QMC=(vol_bb/card)*ones(card_int,1);

end





