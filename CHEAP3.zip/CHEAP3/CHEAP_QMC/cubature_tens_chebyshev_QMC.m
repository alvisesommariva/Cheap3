function chebyshev_moms=cubature_tens_chebyshev_QMC(nodes,weights,...
    chebyshev_indices,dbox)

%--------------------------------------------------------------------------
% Object.
%--------------------------------------------------------------------------
% This routine, having cubature nodes/weights of a cubature rule with nodes
% "nodes" and weights "weights" computes all the moments of the Chebyshev
% basis, scaled in the bounding box of the domain.
%
% The vector "chebyshev_indices" specifies the polynomial degrees, that is
% the indices i, j, k of the tensorial polynomial T_i*T_j*T_k.
%
% As output we provide these moments in the column vector "chebyshev_moms",
% ordered as in "chebyshev_indices", with total degree as
% "chebyshev_total_degrees".
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete 
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Modified object (Oct. 21, 2025)
%--------------------------------------------------------------------------
% Authors: Laura Rinaldi, Alvise Sommariva*, Marco Vianello.
%--------------------------------------------------------------------------


X=nodes(:,1); Y=nodes(:,2); Z=nodes(:,3);

% Map to reference cube [-1,1] x [-1,1] x [-1,1]
a1=dbox(1); b1=dbox(2); A1=(a1+b1)/2; B1=(b1-a1)/2; XN=(X-A1)/B1;
a2=dbox(3); b2=dbox(4); A2=(a2+b2)/2; B2=(b2-a2)/2; YN=(Y-A2)/B2;
a3=dbox(5); b3=dbox(6); A3=(a3+b3)/2; B3=(b3-a3)/2; ZN=(Z-A3)/B3;

ade=max(chebyshev_indices(:,1));
V_QMC = dCHEBVAND(ade,[XN YN ZN],[-1 -1 -1; 1 1 1],chebyshev_indices);

chebyshev_moms=(weights'*V_QMC)';



