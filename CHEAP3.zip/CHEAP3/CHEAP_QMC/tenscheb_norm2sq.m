
function [coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,...
    chebyshev_indices)

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% Input:
%
% ade: total degree of the basis.
% 
% chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
%       by the routine "tenscheb_norm2sq"; in other words if 
%       "tenscheb_norm2sq(s,:)=[i j k]" then the s-th polynomial is
%                       phi_s(x,y,z)=T_i(x) T_j(y) T_k(z)
%       where T_m(u)=cos(m*acos(u)).
%
%--------------------------------------------------------------------------
% Output:
%
% coeffs: computation of (phi_k,phi_k) where phi_k is the k-th tensor
%         product polynomial of the basis used in the Vandermonde matrix.
% chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
%       by the routine "tenscheb_norm2sq"; in other words if 
%       "tenscheb_norm2sq(s,:)=[i j k]" then the s-th polynomial is
%                       T_i(x) T_j(y) T_k(z)
%       where T_m(u)=cos(m*acos(u)).
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------

if nargin < 2
    d=3;
    N = nchoosek(ade+d,d); chebyshev_indices = zeros(N,3);
    for i=2:N
        chebyshev_indices(i,:) = mono_next_grlex(d,...
            chebyshev_indices(i-1,:));
    end
end

coeffs=[];
for k=1:size(chebyshev_indices,1)
    coeffsL=pi^3/2^sum(not(chebyshev_indices(k,:) == 0));
    coeffs=[coeffs; coeffsL];
end
