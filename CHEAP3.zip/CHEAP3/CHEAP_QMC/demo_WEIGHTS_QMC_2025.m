
function demo_WEIGHTS_QMC_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the weights of the QMC cheap rule in some domains.
% In particular,
% 1. computes QMC rule on a test domain (starting from "card" Halton points
%    in a bounding box of the integration domain.
% 2. computes a cheap rule of degree "ade".
% 3. sorts the weights of the cheap rule, providing a figure.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about 
% * 4s (domain 1), 
% * 1s (domain 2).
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> % setting "domain=1"
% >> demo_WEIGHTS_QMC_2025
%
% 	  .......... Settings/Info  ..........
% 	 
% 	  domain: 1
% 	  ade cheap                     : 10
% 	  cardinality cheap rule        : 1331
% 	  cardinality QMC rule (bbox)   : 100000
% 	  cardinality QMC rule (domain) : 23076
% 	 
% 	  See figure with sorted weights
% 	 
% 	 .....................................
% >> % setting "domain=2"
% >> demo_WEIGHTS_QMC_2025
% 
% 	 .......... Settings/Info  ..........
% 
% 	 domain: 2
% 	 ade cheap                     : 10
% 	 cardinality cheap rule        : 1331
% 	 cardinality QMC rule (bbox)   : 100000
% 	 cardinality QMC rule (domain) : 37379
% 
% 	 See figure with sorted weights
% 
% 	 .....................................
% >>
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------

clear all;

domain=2; % Define domain depending on this variable.
card=10^5; % QMC cardinality.
ade=10;    % Degree of precision of the rule.

% ........................ main code below ................................

[pts_QMC,w_QMC,dbox]=provide_domain_QMC(domain,card);


% .................... A. QMC cheap startup ...........................

[XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);


% .................... B. QMC cheap rule ..............................
dboxV=dbox'; dboxV=dboxV(:);
moments_ch=cubature_tens_chebyshev_QMC(pts_QMC,w_QMC,...
    chebyshev_indices,dboxV);

XYZW_tens=scale_rule(XYZW_tens_ref,dboxV);
w1=XYZW_tens(:,4);
w2=V_ref*(moments_ch./coeffs);

W=w1.*w2;

% XYZW=[XYZW_tens(:,1:3) W];

% .................... C. QMC cheap weights plot .......................

W=sort(W);
T=1:length(W); T=T';

plot(T,W,'r.')
hold on;
grid on;
hold off;

% ....................... D. Statistics ................................

fprintf('\n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t domain: %1.0f',domain);
fprintf('\n \t ade cheap                     : %-7.0f',ade);
fprintf('\n \t cardinality cheap rule        : %-7.0f',length(W));
fprintf('\n \t cardinality QMC rule (bbox)   : %-7.0f',card);
fprintf('\n \t cardinality QMC rule (domain) : %-7.0f',length(w_QMC));
fprintf('\n \n \t See figure with sorted weights \n');
fprintf('\n \t .....................................  \n ')

