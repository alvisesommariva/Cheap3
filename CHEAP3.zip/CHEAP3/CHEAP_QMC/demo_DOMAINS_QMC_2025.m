

function demo_DOMAINS_QMC_2025

%--------------------------------------------------------------------------
% Object:
% This demo shows the domains of interest and the cheap pointset.
% Green nodes: positive weights;
% Red nodes  : negative weights.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires from about
% * 3s for domain 1;
% * 3s for domain 2.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% example setting "domain=1".
% >> demo_DOMAINS_QMC_2025
%
% See domain plot in figure.
%
% >> % example setting "domain=2".
% >> demo_DOMAINS_QMC_2025
%
% See domain plot in figure.
%
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 25, 2025
%--------------------------------------------------------------------------

clf; clear all;

example=1; % Define domain depending on this variable.
card=10^5;
ade=10;

% ........................ main code below ................................

[pts_QMC,w_QMC,dbox]=provide_domain_QMC(example,card);


% .................... A. QMC cheap startup ...............................

[XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);


% .................... B. QMC cheap rule ..................................

dboxV=dbox'; dboxV=dboxV(:);
moments_ch=cubature_tens_chebyshev_QMC(pts_QMC,w_QMC,...
    chebyshev_indices,dboxV);

XYZW_tens=scale_rule(XYZW_tens_ref,dboxV);
w1=XYZW_tens(:,4);
w2=V_ref*(moments_ch./coeffs);

W=w1.*w2;

XYZW=[XYZW_tens(:,1:3) W];



% .................... C. Plot pts/weights ................................


figure(1)
ipos=find(W > 0);
my_color='g';
plot3(XYZW(ipos,1),XYZW(ipos,2),XYZW(ipos,3),'o',...
    'MarkerEdgeColor',my_color,'MarkerFaceColor',my_color,'MarkerSize',3);
hold on;
inpos=find(W <= 0);
my_color='r';
plot3(XYZW(inpos,1),XYZW(inpos,2),XYZW(inpos,3),'o','MarkerEdgeColor',...
    my_color,'MarkerFaceColor',my_color,'MarkerSize',3);
hold off;

fprintf('\n \t See domain plot in figure. \n \n');
