
function in=inunionballs(pts,centers,radii)

%-----------------------------------------------------------------------
% Object.
%-----------------------------------------------------------------------
% Determine what points in the matrix "N x 3" named "pts" are in the union
% of balls whose 
% 
% 1. centers are stored in the matrix "M x 3" named "centers" 
% 2. corresponding radii are stored in the vector "M x 1" named "radii".
%
% If "in(k)=1" then the point "pts(k,:)" is in the union of those balls
% otherwise it is not.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%----------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------


cx=centers(:,1); cy=centers(:,2); cz=centers(:,3);
card=size(pts,1);
in=zeros(card,1);

for k=1:card
    x=pts(k,1); y=pts(k,2); z=pts(k,3);
    dist_centers=sqrt( (cx-x).^2 + (cy-y).^2 + (cz-z).^2);
    flag=sum(dist_centers <= radii);

    if flag > 0
        in(k)=1; 
    end 

end