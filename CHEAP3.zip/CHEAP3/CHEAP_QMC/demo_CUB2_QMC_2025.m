
function demo_CUB2_QMC_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the quality of numerical integration of some test
% functions (w.r.t. QMC measure).
%
% The domain "D" is specified as index. Next it chooses the example from a
% list of trivariate domains.
%
% Random nodes of cardinality "card" are defined on a bounding box of the
% domain, so determining by in-domain functions a QMC rule on the domain D.
%
% Cheap-rules having degrees "ade" in "adeV" are then defined.
%
% The routine compares the results of the Cheap-rules with that of QMC
% rule, on three test functions.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires from about 
% * 32s for domain 1;
% *  4s for domain 2.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete 
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> % example setting "domain=1".
% >> demo_CUB2_QMC_2025
%  	 .......... Settings/Info  ..........  
% 
%  	 domain: 1
%  	 cardinality reference QMC rule: 1000000
%  	 cardinality QMC rule (bbox)   :  100000
%  	 cardinality QMC rule (domain) :   23076
% 
%  	 .......... Relative errors QMC Rules  ..........  
% 
%  	 |   f1    |    f2    |    f3    |
%  	 .......................................
%  	   4e-05   &  5e-03   &  4e-04 
% 
%  	 .......... Relative errors Cheap Rules  ..........  
% 
%  	 | ade |    f1    |    f2    |    f3    |
%  	 .......................................
%  	    2  &  3e-02   &  8e+00   &  1e-01 
%  	    4  &  1e-03   &  2e+00   &  6e-03 
%  	    6  &  5e-05   &  6e-02   &  5e-04 
%  	    8  &  4e-05   &  1e-02   &  2e-04 
%  	   10  &  4e-05   &  6e-03   &  3e-04 
%  	   12  &  4e-05   &  5e-03   &  4e-04 
%  	   14  &  4e-05   &  5e-03   &  4e-04 
%  	   16  &  4e-05   &  5e-03   &  4e-04 
% 
% >> % example setting "domain=2".
% >> demo_CUB2_QMC_2025
%
%     .......... Settings/Info  ..........  
% 
%  	 domain: 2
%  	 cardinality reference QMC rule: 1000000
%  	 cardinality QMC rule (bbox)   :  100000
%  	 cardinality QMC rule (domain) :   37379
% 
%  	 .......... Relative errors QMC Rules  ..........  
% 
%  	 |   f1    |    f2    |    f3    |
%  	 .......................................
%  	   6e-04   &  9e-03   &  2e-03 
% 
%  	 .......... Relative errors Cheap Rules  ..........  
% 
%  	 | ade |    f1    |    f2    |    f3    |
%  	 .......................................
%  	    2  &  6e-02   &  5e+01   &  2e-01 
%  	    4  &  6e-03   &  2e+01   &  2e-02 
%  	    6  &  7e-04   &  4e-01   &  1e-03 
%  	    8  &  7e-04   &  4e-01   &  2e-03 
%  	   10  &  6e-04   &  7e-05   &  2e-03 
%  	   12  &  6e-04   &  9e-03   &  2e-03 
%  	   14  &  6e-04   &  9e-03   &  2e-03 
%  	   16  &  6e-04   &  9e-03   &  2e-03 
% 
% >>
%--------------------------------------------------------------------------
% - Modified object (Oct. 21, 2025)
%   Modified line of adeV.
%   Modified below the test functions and their call in the routine.
% - Modified main code (Oct. 21, 2025)
%   Modified code (lines 100-120)
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 25, 2025
%--------------------------------------------------------------------------

clear all;

domain=2; % Define domain depending on this variable.
card_ref=10^6; % QMC cardinality (ref.results).
card=10^5; % QMC cardinality (QMC in tests).
adeV=2:2:16; % Degree of precision of the rule.


% ........................ main code below ............................

% A. QMC reference points in example.
[pts_QMC_ref,w_QMC_ref,dbox]=provide_domain_QMC(domain,card_ref);

% B. Reference results.
for example=1:3
    f=test_functions(example,domain);
    I(example)=w_QMC_ref'*feval(f,pts_QMC_ref(:,1),pts_QMC_ref(:,2),...
        pts_QMC_ref(:,3));
end

% C. Results of QMC rule
I_QMC=[];
[pts_QMC,w_QMC,dbox]=provide_domain_QMC(domain,card); % QMC rule
for example=1:3
    f=test_functions(example,domain);
    I_QMC(example)=w_QMC'*feval(f,pts_QMC(:,1),pts_QMC(:,2),...
        pts_QMC(:,3));
end


% D. Compute experiments with cheap rules, varying degree.

I_ch=[];
for ii=1:length(adeV)

    ade=adeV(ii);

    % A. Cheap routine.

    % .................... A. QMC cheap startup .......................

    [XYZW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

    % .................... B. QMC cheap rule ..........................

    dboxV=dbox'; dboxV=dboxV(:);
    moments_ch=cubature_tens_chebyshev_QMC(pts_QMC,w_QMC,...
        chebyshev_indices,dboxV);

    XYZW_tens=scale_rule(XYZW_tens_ref,dboxV);
    w1=XYZW_tens(:,4);
    w2=V_ref*(moments_ch./coeffs);

    W=w1.*w2;

    XYZW=[XYZW_tens(:,1:3) W];

    % .................... D. cheap rule integration ..................
    for example=1:3
        f=test_functions(example,domain);
        Ich_loc(1,example)=W'*feval(f,XYZW(:,1),XYZW(:,2),XYZW(:,3));
    end

    I_ch=[I_ch; Ich_loc];

end


% E. Statistics
fprintf('\n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t domain: %1.0f',domain);
fprintf('\n \t cardinality reference QMC rule: %7.0f',card_ref);
fprintf('\n \t cardinality QMC rule (bbox)   : %7.0f',card);
fprintf('\n \t cardinality QMC rule (domain) : %7.0f',length(w_QMC));

fprintf('\n \n \t .......... Relative errors QMC Rules  ..........  \n ')

fprintf('\n \t |   f1    |    f2    |    f3    |')
fprintf('\n \t .......................................')
for k=1:3
    RE_QMC(k)=abs(I_QMC(:,k)-I(k))/abs(I(k));
end
fprintf('\n \t   %1.0e   &  %1.0e   &  %1.e ',...
    RE_QMC(1),RE_QMC(2),RE_QMC(3)); 

fprintf('\n \n \t .......... Relative errors Cheap Rules  ..........  \n ')


fprintf('\n \t | ade |    f1    |    f2    |    f3    |')
fprintf('\n \t .......................................')
for k=1:3
    RE(:,k)=abs(I_ch(:,k)-I(k))/abs(I(k));
end

for k=1:length(adeV)
    fprintf('\n \t   %2.0f  &  %1.0e   &  %1.0e   &  %1.e ',adeV(k), ...
        RE(k,1),RE(k,2),RE(k,3));
end

fprintf('\n \n');






function f=test_functions(example,domain)

%--------------------------------------------------------------------------
% Modified test functions (Oct. 21, 2025)
%--------------------------------------------------------------------------
% Authors: Laura Rinaldi, Alvise Sommariva*, Marco Vianello.
%--------------------------------------------------------------------------

if nargin < 2
    domain=1;
end

switch domain
    case 1
        x0=0.51;    y0=0.26;    z0=0.63;
    case 2
        x0=0.2100;    y0=0.3600;    z0=0.5100;
    otherwise
        x0=0;    y0=0;    z0=0;
end

switch example
    case 1
        f=@(x,y,z) exp(-(x.^2+y.^2+z.^2));
    case 2
        f=@(x,y,z) ((x-x0).^2+(y-y0).^2+(z-z0).^2).^(11/2);
    case 3
        f=@(x,y,z) ((x-x0).^2+(y-y0).^2+(z-z0).^2).^(3/2);
end

