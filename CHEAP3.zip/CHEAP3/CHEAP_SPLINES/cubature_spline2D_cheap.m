
function [XYW,XYW_tens_ref,chebyshev_indices,V_ref]=...
    cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,...
    chebyshev_indices,V_ref,coeffs)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% This routine computes nodes and weights of a cubature formula with degree
% of precision "ade" on a bivariate spline curvilinear polygon.S
%
% The formula is defined by nodes in the bounding box (so not necessarily
% belonging to the domain) and possibly negative weights.
% In spite of that the formula is stable since the condition number of the
% integration is bounded.
%-----------------------------------------------------------------------
% Input:
%-----------------------------------------------------------------------
% Sx, Sy: determine the spline boundary via the vectors of splines "Sx" and 
%         "Sy".
%
% ade: algebraic degree of precision of the rule (total degree).
%
% * XYW_tens_ref: precomputed nodes and weights of a tensorial rule, in  
%    the domain [-1,1]^2. The first three columns represent the coordinates 
%    of the nodes, the last column the respective weights.
%    Thus x=XYW_tens_ref(:,1), y=XYW_tens_ref(:,2),
%    and w=XYW_tens_ref(:,3) define a rule with nodes (x,y) and weights
%    "w".
%
% * chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
%       by the routine "tenscheb_norm2sq"; in other words if 
%       "tenscheb_norm2sq(s,:)=[i j]" then the s-th polynomial is
%                       T_i(x) T_j(y)
%       where T_m(u)=cos(m*acos(u)).
% 
% * V_ref: Vandermonde matrix of the pointset "XYW_tens_ref(:,1:2)", w.r.t.
%    a certain tensorial polynomial basis of Chebyshev type. It is defined
%    by the routine "dCHEBVAND".
%
% * coeffs:
%
% Note: The variables in which there is an asterisk are not mandatory.
%-----------------------------------------------------------------------
% Output:
%-----------------------------------------------------------------------
% XYW: The variable "XYW" is a matrix with "m" rows (that is the
%  cardinality of the cubature pointset) and 4 columns.
%  The first 2 columns are the coordinates of the nodes of a
%  rule over the domain, while the 3th column represent the
%  corresponding weights.
%
% XYW_tens_ref: precomputed nodes and weights of a tensorial rule, in the 
%    domain [-1,1]^2. The first 2 columns represent the coordinates of
%    the nodes, the last column the respective weights.
%    Thus x=XYW_tens_ref(:,1), y=XYW_tens_ref(:,2), 
%    and w=XYW_tens_ref(:,3) define a rule with nodes (x,y) and weights
%    "w".
%
% chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
% by the routine "tenscheb_norm2sq".
% 
% V_ref: Vandermonde matrix of the pointset "XYW_tens_ref(:,1:2)", w.r.t.
%    a certain tensorial polynomial basis of Chebyshev type. It is defined
%    by the routine "dCHEBVAND".
%-----------------------------------------------------------------------
% Routines called directly by "cubature_polyhedron_cheap_001":
%
% 1. scale_rule (attached)
% 2. spline_chebmom (attached)
%-----------------------------------------------------------------------
% Data:
% First version: January 11, 2025.
% Latest version: October 21, 2025.
%-----------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------


% ........................... COMPUTE MOMENTS ..........................
[moments_ch,dbox]=spline_chebmom(ade,Sx,Sy);

XYW_tens=scale_rule(XYW_tens_ref,dbox);
w1=XYW_tens(:,3);
w2=V_ref*(moments_ch./coeffs);

W=w1.*w2;

XYW=[XYW_tens(:,1:2) W];









function XYW_tens=scale_rule(XYW_tens_ref,dbox)

%-----------------------------------------------------------------------
% Object:
%-----------------------------------------------------------------------
% Scale reference nodes from [-1,1]^2 to the bounding box.
%
% Note:
% For the needs of the routine it is not required to scale also the
% weights.
%-----------------------------------------------------------------------

a=dbox(1); b=dbox(2);
X=XYW_tens_ref(:,1);
X=(a+b)/2 + ((b-a)/2)*X;

a=dbox(3); b=dbox(4);
Y=XYW_tens_ref(:,2);
Y=(a+b)/2 + ((b-a)/2)*Y;

W=XYW_tens_ref(:,3);

XYW_tens=[X Y W];

















