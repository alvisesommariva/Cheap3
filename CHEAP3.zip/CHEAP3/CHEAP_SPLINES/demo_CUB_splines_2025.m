s
function demo_CUB_splines_2025

%--------------------------------------------------------------------------
% Object:
% This demo shows the quality of numerical integration of some test
% functions.
%--------------------------------------------------------------------------
% Important: it requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 1 second. 
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> demo_CUB_splines_2025
% 
%  	             Relative errors 
% 
%  	 | ade |    f1    |    f2    |    f3    |
%  	 .................................... ...
%  	   2  & 7e-05 & 3e-01 & 4e-02 \
%  	   4  & 9e-07 & 6e-01 & 3e-03 \
%  	   6  & 2e-09 & 2e-02 & 2e-05 \
%  	   8  & 4e-12 & 2e-03 & 8e-05 \
%  	  10  & 1e-14 & 5e-05 & 5e-05 \
%  	  12  & 2e-15 & 5e-06 & 2e-06 \
%  	  14  & 9e-16 & 5e-07 & 1e-05 \
%  	  16  & 6e-16 & 5e-08 & 2e-06 \
% 
% >> 
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------



%..........................................................................
% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
%..........................................................................

example=2;

% Curvilinear splines boundary (definition).
[vertices,spline_parms]=define_domain(example);

spline_type='variational';
% Degree of precision of the rule.



% Degree of precision of the rule.
adeV=2:2:16;

% ........................ main code below ............................

% A. Determine the spline boundary via the vectors of splines "Sx" and "Sy".
 X=vertices(:,1); Y=vertices(:,2);
    [Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);


% B. Compute reference values..

    % 1. Startup.
    ade=30;
    [XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

    % 2. Determine Cheap rule.
    XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,chebyshev_indices,...
        V_ref,coeffs);

    XX=XYWch(:,1); YY=XYWch(:,2); WW=XYWch(:,3);

for example=1:3
    f=test_functions(example);
    I(example)=WW'*feval(f,XX,YY);
end

% C. Compute experiments, varying degree.

I_ch=[];
for ii=1:length(adeV)

    ade=adeV(ii);

    % Cheap routine.

    % 1. Startup.
    [XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

    % 2. Determine Cheap rule.
    XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,chebyshev_indices,...
        V_ref,coeffs);

    XX=XYWch(:,1); YY=XYWch(:,2); WW=XYWch(:,3);

    for example=1:3
    f=test_functions(example);
    Ich_loc(1,example)=WW'*feval(f,XX,YY);
    end

    I_ch=[I_ch; Ich_loc];

end



% D. Statistics

fprintf('\n \t             Relative errors \n ') 
fprintf('\n \t | ade |    f1    |    f2    |    f3    |')
fprintf('\n \t .................................... ...')
for k=1:3
  RE(:,k)=abs(I_ch(:,k)-I(k))/abs(I(k));
end

for k=1:length(adeV)
  fprintf('\n \t  %2.0f  & %1.0e & %1.0e & %1.e \\',adeV(k), ...
      RE(k,1),RE(k,2),RE(k,3));
 % fprintf('\n \t | %2.0f  | %1.2e | %1.2e | %1.2e |',adeV(k), ...
 % RE(k,1),RE(k,2),RE(k,3));
end

hold off;
fprintf('\n \n');






function f=test_functions(example)

switch example
    case 1
        f=@(x,y) exp(-(x.^2+y.^2));
    case 2
        f=@(x,y) (x.^2+y.^2).^(11/2);
    case 3
        f=@(x,y) (x.^2+y.^2).^(3/2);
end



