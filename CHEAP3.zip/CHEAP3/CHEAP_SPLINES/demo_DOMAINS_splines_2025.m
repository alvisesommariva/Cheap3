
function demo_DOMAINS_splines_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the domains of interest and the cheap pointset.
%--------------------------------------------------------------------------
% Important: it requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 3 seconds.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> demo_DOMAINS_splines_2025
%
% Figure 1: Domain and cheap points (green: w > 0, red: w < 0)
% Figure 2: Weights distribution.
%
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------



%..........................................................................
% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
%..........................................................................

example=2;

% Curvilinear splines boundary (definition).
[vertices,spline_parms]=define_domain(example);

spline_type='variational';

% Degree of precision of the rule.
ade=10;


% ........................ main code below ............................

% Determine the spline boundary via the vectors of splines "Sx" and "Sy".
X=vertices(:,1); Y=vertices(:,2);
[Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);


% Plot domain domain boundary and nodes
clf;

figure(1);

% 1. domain boundary

plot_splines2D(Sx,Sy);
hold on;

% 2. pointset cheap

% 1. Startup.
[XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

% 2. Determine Cheap rule.
XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,chebyshev_indices,...
    V_ref,coeffs);

XX=XYWch(:,1); YY=XYWch(:,2); WW=XYWch(:,3);

% my_color=[240,240,240]/256;

ipos=find(WW > 0);

my_color='g';
plot(XX(ipos),YY(ipos),'o','MarkerEdgeColor',my_color,...
    'MarkerFaceColor',my_color,'MarkerSize',3);

inpos=find(WW <= 0);
my_color='r';
plot(XX(inpos),YY(inpos),'o','MarkerEdgeColor',my_color,...
    'MarkerFaceColor',my_color,'MarkerSize',3);
hold off;


figure(2);
WWo=sort(WW);
my_color='r';
grid on;
hold on;
plot(1:length(WWo),WWo,'o','MarkerEdgeColor',my_color,...
    'MarkerFaceColor',my_color,'MarkerSize',3);
hold off;

% message to user
fprintf('\n \t Figure 1: Domain and cheap points (green: w > 0, red: w < 0)');
fprintf('\n \t Figure 2: Weights distribution.');
fprintf('\n \n');