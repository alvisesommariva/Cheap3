
function demo_SUMWEIGHTS_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the sum of the absolute value of weights of the cheap
% rule in some domains, so discussing the stability of the rules.
%
% In particular,
% 1. computes ref. rule on a test domain;
% 2. computes a cheap rule of degree "ade";
% 3. evaluate the sum of the absolute values of the weights.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about
% * 1s (domain 1),
% * 1s (domain 2).
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> % setting "domain=1"
% >> demo_WEIGHTS_QMC_2025
%
% .......... Settings/Info  ..........
%
% domain: 1
% ade cheap                     : 16
% cardinality cheap rule        : 289
%
% See figure with sorted weights
%
% ...............................................
%
% | ade |   sum(W)   |  abs(sum(W)) |  ratio |
% ...............................................
%   2   &  2.077e+00 &  2.386e+00 & 1.15e+00
%   4   &  2.077e+00 &  2.363e+00 & 1.14e+00
%   6   &  2.077e+00 &  2.393e+00 & 1.15e+00
%   8   &  2.077e+00 &  2.331e+00 & 1.12e+00
%  10   &  2.077e+00 &  2.283e+00 & 1.10e+00
%  12   &  2.077e+00 &  2.289e+00 & 1.10e+00
%  14   &  2.077e+00 &  2.267e+00 & 1.09e+00
%  16   &  2.077e+00 &  2.256e+00 & 1.09e+00
% ...............................................
%
% >> % setting "domain=2"
% >> demo_WEIGHTS_QMC_2025
%
% .......... Settings/Info  ..........
%
% domain: 2
% ade cheap                     : 16
% cardinality cheap rule        : 289
%
% See figure with sorted weights
%
% ...............................................
%
% | ade |   sum(W)   |  abs(sum(W)) |  ratio |
% ...............................................
%   2   &  1.866e-01 &  1.953e-01 & 1.05e+00
%   4   &  1.866e-01 &  1.961e-01 & 1.05e+00
%   6   &  1.866e-01 &  2.009e-01 & 1.08e+00
%   8   &  1.866e-01 &  1.952e-01 & 1.05e+00
%  10   &  1.866e-01 &  1.978e-01 & 1.06e+00
%  12   &  1.866e-01 &  1.943e-01 & 1.04e+00
%  14   &  1.866e-01 &  1.953e-01 & 1.05e+00
%  16   &  1.866e-01 &  1.940e-01 & 1.04e+00
% ...............................................
%
% >>
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 25, 2025
%--------------------------------------------------------------------------

%..........................................................................
% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
%..........................................................................

domain=2;

% Curvilinear splines boundary (definition).
[vertices,spline_parms]=define_domain(domain);

spline_type='variational';

% Degree of precision of the rule.
adeV=2:2:16;


% ........................ main code below ................................


% ....................... A. Determine spline boundary ....................
X=vertices(:,1); Y=vertices(:,2);
[Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);

sum_W=[]; sum_absW=[];

for ade=adeV

    % ....................... B. Cheap rules ..............................

    % 1. Startup.
    [XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

    % 2. Determine Cheap rule.
    XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,...
        chebyshev_indices,V_ref,coeffs);

    XX=XYWch(:,1); YY=XYWch(:,2); WW=XYWch(:,3);

    sum_W=[sum_W; sum(WW)];
    sum_absW=[sum_absW; (sum(abs(WW)))];

end



% ....................... D. Statistics ................................

fprintf('\n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t domain: %1.0f',domain);
fprintf('\n \t ade cheap                     : %-7.0f',ade);
fprintf('\n \t cardinality cheap rule        : %-7.0f',length(WW));
fprintf('\n \n \t See figure with sorted weights \n');
fprintf('\n \t ...............................................   ')

fprintf('\n \n \t | ade |   sum(W)   |  abs(sum(W)) |  ratio |')
fprintf('\n \t ...............................................   ')

for k=1:length(adeV)
    fprintf('\n \t  %2.0f   &  %1.3e &  %1.3e & %1.2e',adeV(k),sum_W(k),...
        sum_absW(k),sum_absW(k)/sum_W(k));
end


fprintf('\n \t ...............................................   \n \n')