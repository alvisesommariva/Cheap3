
function XYZW=cub_gausscheb_tens2D(deg)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Tensorial Gauss-Chebyshev rule on the square [-1,1]^2.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Modified object (Oct. 21, 2025)
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------


card_gs=ceil((deg+1)/2);

[x,w]=gauss_cheb(card_gs);

[X,Y]=meshgrid(x); 
[WX,WY]=meshgrid(w);

XYZW=[X(:) Y(:) (WX(:)).*(WY(:))];







function [x,w]=gauss_cheb(deg)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Gauss-Chebyshev rule on (-1,1).
%--------------------------------------------------------------------------
% Modified object (Oct. 21, 2025)
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------

i=1:deg;
x=cos((2*i'-1)*pi/(2*deg));
w=(pi/deg)*ones(size(x));


