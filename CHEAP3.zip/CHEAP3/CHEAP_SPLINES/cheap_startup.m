
function [XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade)

%--------------------------------------------------------------------------
% Object.
%--------------------------------------------------------------------------
% The cheap algorithm requires a startup that can be used for rules over
% bivariate domains.
%
% The variables computed here are independent from the domain and can be
% computed and even stored for computing rules with degree of exactness
% "ade" on any polyhedra.
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------



% A. compute moments
XYW_tens_ref=cub_gausscheb_tens2D(2*ade);

% B. compute basis indices (tens. cheb. basis ordering)
d=2; chebyshev_indices = [];
for i=0:ade
    for j=0:ade-i
        chebyshev_indices(end+1,:) = [i j];
    end
end

% C. reference Vandermonde matrix
X=XYW_tens_ref(:,1:2);
V_ref = dCHEBVAND(ade,X,[-1 -1; 1 1],chebyshev_indices);

% D. scalar products of basis elements.
[coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,chebyshev_indices);