
function demo_WEIGHTS_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the weights of the cheap rule in some domains.
% In particular,
% 1. computes ref. rule on a test domain;
% 2. computes a cheap rule of degree "ade";
% 3. sorts the weights of the cheap rule, providing a figure.
%--------------------------------------------------------------------------
% Routine time.
%--------------------------------------------------------------------------
% The present routine requires about 
% * 1s (domain 1), 
% * 1s (domain 2).
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> % setting "domain=1"
% >> demo_WEIGHTS_QMC_2025
%
% >> % setting "domain=2"
% >> demo_WEIGHTS_QMC_2025
% 
% >>
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 25, 2025
%--------------------------------------------------------------------------

%..........................................................................
% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
%..........................................................................

domain=1;

% Curvilinear splines boundary (definition).
[vertices,spline_parms]=define_domain(domain);

spline_type='variational';

% Degree of precision of the rule.
ade=10;


% ........................ main code below ................................


% ....................... A. Determine spline boundary ....................

X=vertices(:,1); Y=vertices(:,2);
[Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);


% ....................... B. Cheap rules ..................................

% 1. Startup.
[XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

% 2. Determine Cheap rule.
XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,chebyshev_indices,...
    V_ref,coeffs);

XX=XYWch(:,1); YY=XYWch(:,2); WW=XYWch(:,3);


% ....................... C. Plot weights .................................

clf;
figure(1);
WWo=sort(WW);
my_color='r';
grid on;
hold on;
plot(1:length(WWo),WWo,'o','MarkerEdgeColor',my_color,...
    'MarkerFaceColor',my_color,'MarkerSize',3);
hold off;


% ....................... D. Statistics ................................

fprintf('\n \t .......... Settings/Info  ..........  \n ')
fprintf('\n \t domain: %1.0f',domain);
fprintf('\n \t ade cheap                     : %-7.0f',ade);
fprintf('\n \t cardinality cheap rule        : %-7.0f',length(WW));
fprintf('\n \n \t See figure with sorted weights \n');
fprintf('\n \t .....................................  \n ')

