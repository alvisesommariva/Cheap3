
function XYW = splinegauss_2020(ade,Sx,Sy)

%--------------------------------------------------------------------------
% Object:
% Determining cubature rule having algebraic degree of exactness "ade" on a
% spline curvilinear domain determined parametrically by splines in each
% variable.
%--------------------------------------------------------------------------
% Input:
% ade: polynomial degree of exactness
%
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be counterclockwise concatenated forming a Jordan curve
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
% i=1,...,end, with end+1:=1.
%
%--------------------------------------------------------------------------
% Output:
% XYW: cubature rule stored as a M x 3 matrix. The rule has nodes (X,Y) 
%      with X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3).
%--------------------------------------------------------------------------
% Reference paper:
%--------------------------------------------------------------------------
% For more details consider
% [1] A. Sommariva and M. Vianello
% "Gauss-Green cubature and moment computation over arbitrary geometries"
% Journal of Computational and Applied Mathematics 231 (2009) 886-896
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Authors:
% Alvise Sommariva and Marco Vianello
% University of Padova, September 20, 2020.
%--------------------------------------------------------------------------
%% Copyright (C) 2020 Alvise Sommariva, Marco Vianello.
%%
%% This program is free software; you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation; either version 2 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program; if not, write to the Free Software
%% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%%
%% Author:  Alvise Sommariva <alvise@math.unipd.it>
%%          Marco Vianello   <marcov@math.unipd.it>       
%% Date: September 20, 2020 / October 26, 2025.
%--------------------------------------------------------------------------

% Rotate the spline curvilinear domain "omega" into the spline curvilinear
% domain "D" that more likely will contain more internal nodes after the
% cubature process.

% tic;
[Sx_out,Sy_out,rot_matrix,xi]=domain_rotation(Sx,Sy);
% toc;
% Compute cubature formula over "D", having degree of precision "ade".

% tic;
XYW_D = splinegauss_2020_basic(ade,Sx_out,Sy_out,xi);
% toc;

% Map back the rule.
% tic;
XY_D=XYW_D(:,1:2); XY=XY_D*rot_matrix; XYW=[XY XYW_D(:,3)];
% toc;







function XYW = splinegauss_2020_basic(ade,Sx,Sy,xi)

%--------------------------------------------------------------------------
% Object:
% Determining cubature rule having algebraic degree of exactness "ade" on a
% spline curvilinear domain determined parametrically by splines in each
% variable.
%--------------------------------------------------------------------------
% Input:
% ade: polynomial degree of exactness
%
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be counterclockwise concatenated forming a Jordan curve
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
% i=1,...,end, with end+1:=1
%
% xi: parameter defining a "reference" ver% tical axis (default: xi=0)
%
%--------------------------------------------------------------------------
% Output:
% XYW: cubature rule store as a M x 3 matrix. The rule has nodes (X,Y) with
%      X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3).
%--------------------------------------------------------------------------
% Reference paper:
%
% For more details consider
% [1] A. Sommariva and M. Vianello
% "Gauss-Green cubature and moment computation over arbitrary geometries"
% Journal of Computational and Applied Mathematics 231 (2009) 886-896
%--------------------------------------------------------------------------

% .............. troubleshooting ..............

if nargin < 4, xi=0; end
if (isempty(xi)), xi=0; end

% .............. formula computation ..............

XYW=[];

% Number of spline curvilinear sides
L=length(Sx);

% By checking the construction of the tensorial rule, one observe that
% independently of the spline order, the code has always to compute a one
% dimensional Gauss-Legendre rule of degree "ade".
% We compute this rule only once, the first time we use the tensorial rule.
% In order to make the work work, we set it equal to the null matrix.

XYW_X=[];

for i=1:L
    
    % Determine curvilinear sides
    SXL=Sx(i); SYL=Sy(i);
    
    % The choice of the degree of precision by direction in described in [1]
    % at page 889, 2 rows after formula (19).
    % In that formula "p_i" is the degree of the spline (i.e. its order
    % minus 1).
    ade_x=ade; 
    
    % In [1], it is "ade=2n-1" thus "2n=ade+1" and 
    % "2*n*p_i+p_i-1=(ade+2)*p_i-1".
    p_i=SYL.order-1; ade_y=(ade+2)*p_i-1;

    [XYW_square,XYW_X]=tensorial_cubature_square(ade_x,ade_y,XYW_X);
    
    % Using tensorial rule to obtain rule on spline curvilinear patch.
    XYW_L=rule_map(XYW_square,SXL,SYL,xi);
    XYW=[XYW; XYW_L];
    
end
    
    
    







function [XYW,XW_X]=tensorial_cubature_square(ade_x,ade_y,XW_X)

%--------------------------------------------------------------------------
% Object:
% In this routine we compute a cubature rule over the square, having degree
% of precision "ade_x" in the "x" variable and "ade_y" in the "y".
%--------------------------------------------------------------------------
% Input:
% ade_x: degree of precision of the cubature rule over the square in the
%       variable x.
% ade_y: degree of precision of the cubature rule over the square in the
%       variable y.
% XW_X:  cubature rule store as a M x 2 matrix. This Gauss-Legendre rule
%     has nodes X with X=XYW(:,1) and weights W=XYW(:,2).
%--------------------------------------------------------------------------
% Output:
% XYW: cubature rule store as a M x 3 matrix. The rule has nodes (X,Y) with
%      X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3)
%--------------------------------------------------------------------------
% Observation (valif for spline curvilinear cubature):
% By checking the construction of the tensorial rule in [1], one observe that
% independently of the spline order, the code has always to compute a one
% dimensional Gauss-Legendre rule of degree "ade_x".
% We compute this rule only once, and in case it is available we use again,
% without recomputing it again.
%--------------------------------------------------------------------------
% Reference paper:
%
% For more details consider
% [1] A. Sommariva and M. Vianello
% "Gauss?Green cubature and moment computation over arbitrary geometries"
% Journal of Computational and Applied Mathematics 231 (2009) 886?896
%--------------------------------------------------------------------------
% Authors:
% Alvise Sommariva and Marco Vianello
% September 18, 2020
%--------------------------------------------------------------------------

if nargin < 3
    XW_X=[];
end

Nx=ceil((ade_x+1)/2);

% ...................... RULE IN THE X VARIABLE  .......................... 

% If the rule in the x variable is not know, the code determines its nodes
% and weights.

if size(XW_X,1) == 0
    Nx=ceil((ade_x+1)/2);
    ab=r_jacobi(Nx,0,0); XW_X=gauss(Nx,ab); Xx=XW_X(:,1); Wx=XW_X(:,2);
else
    Xx=XW_X(:,1); Wx=XW_X(:,2);
end

% ...................... RULE IN THE Y VARIABLE  .......................... 


Ny=ceil((ade_y+1)/2);

if Nx == Ny
    XW_Y=XW_X;
else
    ab=r_jacobi(Ny,0,0); XW_Y=gauss(Ny,ab);
end
Xy=XW_Y(:,1); Wy=XW_Y(:,2);


% ...................... TENSORIAL RULE ASSEMBLY  ......................... 


[X,Y]=meshgrid(Xx,Xy); X=X(:); Y=Y(:);
[WWx,WWy]=meshgrid(Wx,Wy);
W=WWx.*WWy; W=W(:);
XYW=[X Y W];







% ...................... GAUSSIAN RULE  ......................... 

% GAUSS Gauss quadrature rule.
%
%    Given a weight function w encoded by the nx2 array ab of the
%    first n recurrence coefficients for the associated orthogonal
%    polynomials, the first column of ab containing the n alpha-
%    coefficients and the second column the n beta-coefficients,
%    the call xw=GAUSS(n,ab) generates the nodes and weights xw of
%    the n-point Gauss quadrature rule for the weight function w.
%    The nodes, in increasing order, are stored in the first
%    column, the n corresponding weights in the second column, of
%    the nx2 array xw.
%
function xw=gauss(N,ab)
N0=size(ab,1); if N0<N, error('input array ab too short'), end
J=zeros(N);
for n=1:N, J(n,n)=ab(n,1); end
for n=2:N
    J(n,n-1)=sqrt(ab(n,2));
    J(n-1,n)=J(n,n-1);
end
[V,D]=eig(J);
[D,I]=sort(diag(D));
V=V(:,I);
xw=[D ab(1,2)*V(1,:)'.^2];







% ...................... ORTH. POLY. RECURSION  ......................... 

function ab=r_jacobi(N,a,b)

nu=(b-a)/(a+b+2);
mu=2^(a+b+1)*gamma(a+1)*gamma(b+1)/gamma(a+b+2);
if N==1
    ab=[nu mu]; return
end

N=N-1;
n=1:N;
nab=2*n+a+b;
nuadd=(b^2-a^2)*ones(1,N)./(nab.*(nab+2));
A=[nu nuadd];
n=2:N;
nab=nab(n);
B1=4*(a+1)*(b+1)/((a+b+2)^2*(a+b+3));
B=4*(n+a).*(n+b).*n.*(n+a+b)./((nab.^2).*(nab+1).*(nab-1));
abadd=[mu; B1; B'];
ab=[A' abadd];










function XYW_domain=rule_map(XYW,S1,S2,xi)

%--------------------------------------------------------------------------
% Object:
% These routine, from a certain tensorial rule on the square XYW determines
% some nodes and weights, useful to compute a rule on spline-curvilinear
% domain.
%
% For more details consider formula (18) at page 888 of:
% [1] A. Sommariva and M. Vianello
% "Gauss?Green cubature and moment computation over arbitrary geometries"
% Journal of Computational and Applied Mathema% fprintfs 231 (2009) 886?896
%--------------------------------------------------------------------------
% Input:
% XYW: cubature rule store as a M x 3 matrix. The rule has nodes (X,Y) with
%      X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3).
% S1, S2: splines defining the boundary of the domain (they must have the
%      same order and parametrization subintervals [t(i),t(i+1)].
% xi:  reference point
%--------------------------------------------------------------------------
% Output:
% XYW_domain: cubature rule store as a M x 3 matrix. The rule has nodes
%      (X,Y) with X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3) and it is
%      the main block for computing the wanted rule on the
%      spline-curvilinear domain.
%--------------------------------------------------------------------------

% This notation is the same used in [1], page 888, formula (18).

tau=XYW(:,1); u=XYW(:,2); w=XYW(:,3);

%.......................................................................... 
% % Breakpoints tij. We suppose that "S1.breaks" is equal to "S2.breaks".
% tij=S1.breaks;
% 
% % Number of subintervals given by spline breaks to be considered.
% L=length(tij-1);
% 
% XYW_domain=[];
% 
% % computing S2 derivative
% % see: https://in.mathworks.com/matlabcentral/answers/
% %      95194-how-do-i-find-the-derivative-of-a-spline-curve-in-
% %      matlab-7-9-r2009b
% 
% [breaks,coefs,l,k,d] = unmkpp(S2);
% S2_prime = mkpp(breaks,repmat(k-1:-1:1,d*l,1).*coefs(:,1:k-1),d);
% 
% for j=1:L-1
%     
%     % ........ Computation of "t0=t_{i,j}" and "t1=t_{i,j+1}" ........
%     t0=tij(j);
%     t1=tij(j+1);
%     delta_tij=t1-t0;
%     aver_t0_t1=(t0+t1)/2;
%     
%     % ........ Computing cubature nodes ........
%     
%     qij_u=(delta_tij/2)*u+aver_t0_t1;
%     
%     S1_qij_u=ppval(S1,qij_u);
%     
%     XL=((S1_qij_u-xi)/2).*tau+(S1_qij_u+xi)/2;
%     
%     YL=ppval(S2,qij_u);
%     
%     % ........ Computing weights ........
%     
%     % determining weights
%     term1=delta_tij/4;
%     term2=S1_qij_u-xi;
%     
%     term3=ppval(S2_prime,qij_u);
%     
%     WL=term1*term2.*term3.*w;
%     
%     XYW_domain=[XYW_domain; XL YL WL];
%     
% end
%..........................................................................         
% Note:
% The procedure below is equivalent to the same code above but is
% in vector form.
% The advantage that one gets is that the code runs faster.
%.......................................................................... 

[breaks,coefs,l,k,d] = unmkpp(S2);
S2_prime = mkpp(breaks,repmat(k-1:-1:1,d*l,1).*coefs(:,1:k-1),d);

t=S1.breaks; % row vector of spline breaks
M=length(u);
L=length(t)-1;

delta_t=diff(t); % row vector
delta_t_rep=repmat(delta_t,M,1); delta_t_rep=delta_t_rep(:);
aver_t=(t(1:end-1)+t(2:end))/2;
aver_t_rep=repmat(aver_t,M,1); aver_t_rep=aver_t_rep(:);

tau_rep=repmat(tau,L,1);
u_rep=repmat(u,L,1);
w_rep=repmat(w,L,1);

% ........ Computing cubature nodes and weights ........

qij_u=(delta_t_rep/2).*u_rep+aver_t_rep;
S1_qij_u=ppval(S1,qij_u);
term1=delta_t_rep/4;
term2=S1_qij_u-xi;
term3=ppval(S2_prime,qij_u);
W=term1.*term2.*term3.*w_rep;

X=(term2/2).*tau_rep+(S1_qij_u+xi)/2;
Y=ppval(S2,qij_u);

XYW_domain=[X Y W];










function [Sx_out,Sy_out,rot_matrix,xi]=domain_rotation(Sx_in,Sy_in)

%--------------------------------------------------------------------------
% Object:
% Determining a rotation of the spline curvilinear domain "Omega" so that
% "many" nodes will be in "Omega".
%
% The key idea is that we rotate the spline curvilinear domain "Omega" in
% "D" so that the cubature rule in "D" will have "many" nodes inside.
%
% By another routine we rotate back the nodes from "D" to "Omega",
% obtaining a rule with the same amount of internal points.
%--------------------------------------------------------------------------
% Input:
% ade: polynomial degree of exactness
%
% Sx_in,Sy_in: arrays of spline structures; (Sx_in(i),yx_in(i)) is the i-th
% arc.
%
% The arcs must be counterclockwise concatenated forming a Jordan curve
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
% i=1,...,end, with end+1:=1.
%
% Here we suppose that the curvilinear domain is tracked parametrically in
% each variable by a certain number of splines so that the k-th spline is
% defined either in x and y in the interval [alpha_k,beta_k].
%
% For more details see [1], Theorem 3.2, p.887.
%--------------------------------------------------------------------------
% Output:
% ade: polynomial degree of exactness
%
% Sx_out,Sy_out: arrays of spline structures; (Sx_out(i),Sy_out(i)) is the
%    i-th arc, determining the boundary of the rotated domain (i.e. the
%    boundary of "D").
%
% rot_matrix: rotation matrix; the spline curvilinear domain "D" is obtain
%     from "Omega", so that if P=[P(1); P(2)] belongs to "Omega" than
%    "rot_matrix*P" belongs to "D" (and viceversa using "rot_matrix'").
%
% xi: it allows to choose a good "xi" in formula (18) for rotated domain
%    "D".
%
%--------------------------------------------------------------------------
% Reference paper:
%
% For more details consider
% [1] A. Sommariva and M. Vianello
% "Gauss?Green cubature and moment computation over arbitrary geometries"
% Journal of Computational and Applied Mathematics 231 (2009) 886?896
%--------------------------------------------------------------------------

% Here we suppose that the curvilinear domain is tracked parametrically in
% each variable by a certain number of splines so that the k-th spline is
% defined either in x and y in the interval [alpha_k,beta_k].
% For more details see [1], Theorem 3.2, p.887.

control_pts=[];
for k=1:length(Sx_in)
    % Sample points points on the k-th curvilinear side, ie. "t" belonging to
    % "[alpha_k,beta_k]" (that is the spline parametrization interval).
    SxL=Sx_in(k); SyL=Sy_in(k);
    t=SxL.breaks; Xt=fnval(SxL,t); Yt=fnval(SyL,t);
    control_pts=[control_pts; Xt' Yt'];
end

% Computing the rotation matrix to allow a high number of nodes of the rule
% to be in the spline curvilinear domain D (rotation of the original domain
% "Omega").
distances = points2distances(control_pts);
max_distance = max(max(distances));
[i1,i2]=find(distances == max_distance);
i1=i1(1); i2=i2(1); % max values may be multiple.

vertex_1=control_pts(i1,:);
vertex_2=control_pts(i2,:);
direction_axis=(vertex_2-vertex_1)/max_distance;

rot_angle_x=acos(direction_axis(1));
rot_angle_y=acos(direction_axis(2));

if rot_angle_y <= pi/2
    if rot_angle_x <= pi/2
        rot_angle=-rot_angle_y;
    else
        rot_angle=rot_angle_y;
    end
else
    if rot_angle_x <= pi/2
        rot_angle=pi-rot_angle_y;
    else
        rot_angle=rot_angle_y;
    end
end


% CLOCKWISE ROTATION.
rot_matrix=[cos(rot_angle) sin(rot_angle);
    -sin(rot_angle) cos(rot_angle)];

number_sides=size(control_pts,1)-1;

axis_abscissa=rot_matrix*vertex_1'; 
xi=axis_abscissa(1);

% Determining the boundary of the domain "D" (rotation of "Omega" via
% "rot_matrix"). In this map the spline boundary of "Omega" is mapped (as
% spline object!) into the spline boundary of "D".

M=length(Sx_in);

for k=1:M
    
    SxL_in=Sx_in(k); SyL_in=Sy_in(k);
    
    SxL_out_A=fncmb(SxL_in,rot_matrix(1,1));
    SxL_out_B=fncmb(SyL_in,rot_matrix(1,2));
    SxL_out=fncmb(SxL_out_A,SxL_out_B);
    
    SyL_out_A=fncmb(SxL_in,rot_matrix(2,1));
    SyL_out_B=fncmb(SyL_in,rot_matrix(2,2));
    SyL_out=fncmb(SyL_out_A,SyL_out_B);
    
    Sx_out(k)=SxL_out; Sy_out(k)=SyL_out;
    
end








%--------------------------------------------------------------------------
% points2distances.
%--------------------------------------------------------------------------

function distances = points2distances(points)

%--------------------------------------------------------------------------
% Object:
% Create euclidean distance matrix from point matrix.
%--------------------------------------------------------------------------
% Input:
% points: set of N bivariate points of which we need to compute the mutual
%    distances, defined as N x 2 matrix of X and Y coordinates.
%--------------------------------------------------------------------------
% Output:
% distances; N x N matrix of mutual distance between points, i.e.
%   "distances(i,j)" is "norm(points(i,:),points(j,:),2)".
%--------------------------------------------------------------------------

% Get dimensions.
[numpoints,~]=size(points);

% All inner products between points.
distances=points*points';

% Vector of squares of norms of points.
lsq=diag(distances);

% Distance matrix.
distances=sqrt(repmat(lsq,1,numpoints)+repmat(lsq,1,numpoints)'-2*distances);



