
function demo_ADE_splines_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows numerically that the rules have the desired algebraic
% degree of exactness.
%--------------------------------------------------------------------------
% Important: it requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 3 seconds. 
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> demo_ADE_splines_2025
% 
%  	 ade:  2 log_aeV: 1.37e-17 log_reV: 2.86e-16
%  	 ade:  4 log_aeV: 4.42e-18 log_reV: 3.87e-16
%  	 ade:  6 log_aeV: 1.71e-18 log_reV: 5.04e-16
%  	 ade:  8 log_aeV: 1.79e-18 log_reV: 1.22e-15
%  	 ade: 10 log_aeV: 6.22e-19 log_reV: 4.76e-16
%  	 ade: 12 log_aeV: 1.23e-19 log_reV: 7.66e-16
%  	 ade: 14 log_aeV: 9.80e-20 log_reV: 6.99e-16
%  	 ade: 16 log_aeV: 2.54e-20 log_reV: 2.76e-15
% 
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------

clf; clear all;

%..........................................................................
% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
%..........................................................................

example=2;

% Curvilinear splines boundary (definition).
[vertices,spline_parms]=define_domain(example);

spline_type='periodic';



% Degree of precision of the rule.
adeV=2:2:16;
number_tests=100;

% ........................ main code below ............................


for ii=1:length(adeV)

    ade=adeV(ii);

    % Determine the spline boundary via the vectors of splines "Sx" and "Sy".
    X=vertices(:,1); Y=vertices(:,2);
    [Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);

    % Cheap routine.

    % 1. Startup.
    [XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);

    % 2. Determine Cheap rule.
    XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,chebyshev_indices,...
        V_ref,coeffs);

    XX=XYWch(:,1); YY=XYWch(:,2); WW=XYWch(:,3);

    % 3, Tests over random polynomials
    for jj=1:number_tests
        % Random polynomial integrand of degree "n"
        k1=rand(1); k2=rand(1); c1=rand(1);
        f=@(x,y) (c1+k1*x+k2*y).^ade;

        % ............. reference result ............
        I_exact = exact_integral(c1,k1,k2,ade,Sx,Sy);

        I_ch=WW'*feval(f,XX,YY);


        % ... Absolute error ...
        aeV(jj)=abs(I_exact-I_ch);

        % ... Absolute error ...
        if abs(I_exact) > 10^(-6) | abs(I_exact) < 10^(+12)
            reV(jj)=abs(I_exact-I_ch)/abs(I_exact);
        else
            reV(jj)=0;
        end
    end

    % % Absolute and relative errors
    % aeVmax(ii)=max(aeV);
    % reVmax(ii)=max(reV);
    %
    % % root mean squares
    % RMS_abs(ii)=rms(log10(aeV(iok1))-mean(log10(aeV(iok1))));
    % RMS_rel(ii)=rms(log10(reV(iok2))-mean(log10(reV(iok2))));

    % ...................... statistics ...............................

    % average error (needs log!)
    iok1=find(aeV > 0);
    log_aeV(ii)=10^(mean(log10(aeV(iok1))));

    iok2=find(reV > 0);
    log_reV(ii)=10^(mean(log10(reV(iok2))));

    fprintf('\n \t ade: %2.0f log_aeV: %1.2e log_reV: %1.2e',...
        ade,log_aeV(ii),log_reV(ii))

    % plots
    plot_errors(ii,adeV,reV,log_reV(ii))

end

hold off;
fprintf('\n \n');







%==========================================================================
% chebmom
%==========================================================================

function [Iexact] = exact_integral(a,b,c,n,Sx,Sy)

% OBJECT:
% computes the exact integral up to degree m of a total-degree polynomial
% (a+bx+cy)^n to the Lebesgue measure in a Jordan spline polygon,
% whose boundary is given by the counterclockwise concatened spline
% arcs (Sx,Sy)
%
% INPUT:
% a,b,c,n: constants for polynomial definition
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be counterclockwise concatenated forming a Jordan curve
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
% i=1,...,end, with end+1:=1

% OUTPUT:
% Iexact: integral value
%
% DATA:
% built: June 6, 2020
% check: June 6, 2020
% modified: June 6, 2020

xyw=lineint(n,Sx,Sy);
intV=intpoly(a,b,c,n,xyw(:,1:2));
Iexact=intV'*xyw(:,3);




%==========================================================================
% lineint
%==========================================================================

function xyw = lineint(m,Sx,Sy)

% OBJECT:
% computes weights and nodes for the line integral on concatenated
% spline arcs; the formula is exact on bivariate polynomials up to deg m
%
% INPUT:
% m = polynomial degree
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be concatenated
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
%
% OUTPUT:
% xyw: 3-column array of nodes coords (cols 1-2) and weights (col 3)
%
% DATA:
% built: March 2019
% check: May 2, 2019

xyw=[];
for i=1:length(Sx)

    ord_spline=Sx(i).order; % degree is the spline order minus 1.

    % Gauss-Legendre nodes in [-1,1] and corresponding weights on the side.
    k=ceil(((ord_spline-1)*(m+2))/2);
    ab=r_jacobi(k,0,0);
    xw=gauss(k,ab);
    t=xw(:,1); w=xw(:,2);

    a=Sx(i).breaks(1:end-1); b=Sx(i).breaks(2:end);
    alpha=(b-a)/2; beta=(b+a)/2;
    dSy(i)=fnder(Sy(i));
    for j=1:length(a)
        nodes=alpha(j)*t+beta(j);
        wloc=w*alpha(j);
        xyw=[xyw;[ppval(Sx(i),nodes) ppval(Sy(i),nodes) ...
            wloc.*ppval(dSy(i),nodes)]];
    end
end





%==========================================================================
% intcvand
%==========================================================================

function intV = intpoly(a,b,c,n,pts)

% computes by recurrence an x-primitive of the polynomial (a+bx+cy)^n on a
% 2d arbitrarily located mesh

% June 2020

% INPUT:
% a,b,c,n: polynomial parameters
% pts: 2-column array of mesh point coordinates

% OUTPUT:
% intV: x-primitive of (a+bx+cy)^n evaluation at pts (column vector)

x=pts(:,1);
y=pts(:,2);

if (n > 0)
    intV=(1/b)*(1/(n+1))*(a+b*x+c*y).^(n+1);
else
    intV=x;
end











%==========================================================================
% r_jacobi
%==========================================================================

function ab=r_jacobi(N,a,b)
%R_JACOBI Recurrence coefficients for monic Jacobi polynomials.
%   AB=R_JACOBI(N,A,B) generates the Nx2 array AB of the first
%   N recurrence coefficients for the monic Jacobi polynomials
%   orthogonal on [-1,1] relative to the weight function
%   w(x)=(1-x)^A*(1+x)^B. The call AB=R_JACOBI(N,A) is the same
%   as AB=R_JACOBI(N,A,A) and AB=R_JACOBI(N) the same as
%   AB=R_JACOBI(N,0,0).
%
%   Supplied by Dirk Laurie, 6-22-1998; edited by Walter
%   Gautschi, 4-4-2002.
%   Edited by Walter Leopardi 10-22-2006.

if nargin<2, a=0; end
if nargin<3, b=a; end
if((N<=0)|(a<=-1)|(b<=-1)) error('parameter(s) out of range'), end
nu=(b-a)/(a+b+2);
if a+b+2 > 128
    mu=exp((a+b+1)*log(2)+((gammaln(a+1)+gammaln(b+1))-gammaln(a+b+2)));
else
    mu=2^(a+b+1)*((gamma(a+1)*gamma(b+1))/gamma(a+b+2));
end
if N==1, ab=[nu mu]; return, end
N=N-1; n=1:N; nab=2*n+a+b;
A=[nu (b^2-a^2)*ones(1,N)./(nab.*(nab+2))];
n=2:N; nab=nab(n);
B1=4*(a+1)*(b+1)/((a+b+2)^2*(a+b+3));
B=4*(n+a).*(n+b).*n.*(n+a+b)./((nab.^2).*(nab+1).*(nab-1));
ab=[A' [mu; B1; B']];





%==========================================================================
% gauss
%==========================================================================

function xw=gauss(N,ab)
%GAUSS Gauss quadrature rule.
%   GAUSS(N,AB) generates the Nx2 array XW of Gauss quadrature
%   nodes and weights for a given weight function W. The nodes,
%   in increasing order, are placed into the first column of XW,
%   and the corresponding weights into the second column. The
%   weight function W is specified by the Nx2 input array AB
%   of recurrence coefficients for the polynomials orthogonal
%   with respect to the weight function W.

N0=size(ab,1); if N0<N, error('input array ab too short'), end
J=zeros(N);
for n=1:N, J(n,n)=ab(n,1); end
for n=2:N
    J(n,n-1)=sqrt(ab(n,2));
    J(n-1,n)=J(n,n-1);
end
[V,D]=eig(J);
[D,I]=sort(diag(D));
V=V(:,I);
xw=[D ab(1,2)*V(1,:)'.^2];




%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,adeV,reV,log_re)

n=adeV(ii);

% set(gca,'YTickLabel',[10.^(-16:1:11)])
%set(gca,'TickLength',[0.1, 0.01])

xmin=min(adeV)-1;
xmax=max(adeV)+1;
xlim([xmin xmax]);

% Get handle to current axes.
ax = gca;
% This sets background color to black.
% ax.Color = 'k'
% ax.YColor = 'r';
% Make the x axis dark green.
% darkGreen = [0, 0.6, 0];
%ax.XColor = darkGreen;
% Make the grid color yellow.
%ax.GridColor = 'y';
% ax.GridAlpha = 0.9; % Set's transparency of the grid.
% Set x and y font sizes.
ax.XAxis.FontSize = 12;
ax.YAxis.FontSize = 12;
% The below would set everything: title, x axis, y axis, and tick mark label font sizes.
% ax.FontSize = 34;
% Bold all labels.
% ax.FontWeight = 'bold';
set(gca,'XTickLabel',{adeV})
C=colororder("glow12");

if ii <= 12
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',C(ii,:)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    plotstr='+';
    semilogy(n*ones(size(reV)),reV,plotstr,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
end

%
% if ii <= 5
%
%     % switch ii
%     %     case 1
%     %         plotstr='m+'; linestr='m-';
%     %     case 2
%     %         plotstr='g+'; linestr='g-';
%     %     case 3
%     %         plotstr='r+'; linestr='r-';
%     %     case 4
%     %         plotstr='b+'; linestr='b-';
%     %     case 5
%     %         plotstr='c+'; linestr='b-';
%     %     otherwise
%     %         plotstr='k.'; linestr='w.';
%     % end
%
% else
%     plotstr='+';
%     semilogy(n*ones(size(reV)),reV,'color',rand(1,3)); hold on;
%     semilogy(n,log_re, 'ko','MarkerSize',29,'MarkerEdgeColor','k');
% end
%
%
%


