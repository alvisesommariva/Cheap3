function plot_splines2D(Sx,Sy)


% ........................ plot preferences ...............................

plot_axis=0;

% ........................... plot: start .................................

if plot_axis == 0, axis off; else, axis on; end

hold on;
............ plot: parametric splines ........................

L=length(Sx);
for ii=1:L
    
    SxL=Sx(ii);
    SyL=Sy(ii);
    
    SxL_breaks=SxL.breaks;
    
    
    Nbreaks=length(SxL_breaks);
    
    for kk=1:Nbreaks-1
        
        t0=SxL_breaks(kk); t1=SxL_breaks(kk+1);
        
        N=10^3;
        tt=linspace(t0,t1,N);
        
        xx=ppval(SxL,tt);
        yy=ppval(SyL,tt);
        
        plot(xx,yy,'k-','LineWidth',4);
    end
    
end

hold off;

