
function demo_CPU_splines_2025

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% This demo shows the cputime required to achieve rules with the desired 
% algebraic degree of exactness, via different algorithms of cheap type
% (cp), PO type (sgPO) and PI-type (sgPI).
%--------------------------------------------------------------------------
% Important: it requires the Matlab built-in "curve fitting toolbox".
%--------------------------------------------------------------------------
% Cputime:
%--------------------------------------------------------------------------
% The demo requires, approximatively, 35 seconds. 
%--------------------------------------------------------------------------
% Related paper:
%--------------------------------------------------------------------------
% "Effective numerical integration on complex shaped elements by discrete
% signed measures", 2025.
% by L. Rinaldi, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% Example:
%--------------------------------------------------------------------------
% >> demo_CPU_splines_2025
% 
%  	             Cardinality 
% 
%  	 | ade |    ch    |   sgPO   |   sgPO   |
%  	 .................................... ...
%  	   2  &       9  &     132  &       6  &
%  	   4  &      25  &     297  &      15  &
%  	   6  &      49  &     528  &      28  &
%  	   8  &      81  &     825  &      45  &
%  	  10  &     121  &    1188  &      66  &
%  	  12  &     169  &    1617  &      91  &
%  	  14  &     225  &    2112  &     120  &
%  	  16  &     289  &    2673  &     153  &
% 
%  	             Cputimes 
% 
%  	 | ade |    ch    |   sgPO   |   sgPO   |
%  	 .................................... ...
%  	   2  & 2e-03 & 3e-03 & 7e-03 \
%  	   4  & 2e-03 & 3e-03 & 7e-03 \
%  	   6  & 2e-03 & 3e-03 & 8e-03 \
%  	   8  & 2e-03 & 2e-03 & 1e-02 \
%  	  10  & 2e-03 & 2e-03 & 2e-02 \
%  	  12  & 2e-03 & 3e-03 & 3e-02 \
%  	  14  & 2e-03 & 2e-03 & 6e-02 \
%  	  16  & 2e-03 & 3e-03 & 1e-01 \
% 
% >>
%--------------------------------------------------------------------------
% Tests.
%--------------------------------------------------------------------------
% Tested on Matlab R2024B, on a PC running Intel(R) N150 (800 MHz) with 16
% GB of RAM.
%--------------------------------------------------------------------------
% License:
%--------------------------------------------------------------------------
% Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% Laura Rinaldi    <laura.rinaldi@unipd.it>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: October 22, 2025
%--------------------------------------------------------------------------



clear all;

%..........................................................................
% Define vertices of the curvilinear polygon.
% Notice that first and last sample point are equal.
%..........................................................................

example=2;

% Curvilinear splines boundary (definition).
[vertices,spline_parms]=define_domain(example);

spline_type='variational';



% Degree of precision of the rule.
adeV=2:2:16;
number_tests=100;

% ........................ main code below ............................

% Determine the spline boundary via the vectors of splines "Sx" and "Sy".
X=vertices(:,1); Y=vertices(:,2);
[Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type);

% Test cputimes
cpus=[];


fprintf('\n \n \t             Cardinality \n ')
fprintf('\n \t | ade |    ch    |   sgPO   |   sgPI   |')
fprintf('\n \t .................................... ...')

for ii=1:length(adeV)

    ade=adeV(ii);

    % A. Cheap routine.
    
    for k=1:number_tests
        
        % 1. Startup.
        [XYW_tens_ref,chebyshev_indices,V_ref,coeffs]=cheap_startup(ade);
        tic;
        % 2. Determine Cheap rule.
        XYWch=cubature_spline2D_cheap(Sx,Sy,ade,XYW_tens_ref,...
            chebyshev_indices,V_ref,coeffs);
        cpusL1(k)=toc;
    end

    % average cputime
    log_aver_cpu(ii,1)=10^(mean(log10(cpusL1)));

    % B. Splinegauss (PO)
    cpusL2=[];
    for k=1:number_tests
        tic;
        XYWPO = splinegauss_2020(ade,Sx,Sy);
        cpusL2(k)=toc;
    end

    % average cputime
    log_aver_cpu(ii,2)=10^(mean(log10(cpusL2)));


    % C. Splinegauss PI
    cpusL3=[];
    for k=1:number_tests
     tic;
        XYWPI = splcub(ade,Sx,Sy);
        cpusL3(k)=toc;
    end

    % average cputime
    log_aver_cpu(ii,3)=10^(mean(log10(cpusL3)));

    fprintf('\n \t  %2.0f  &  %6.0f  &  %6.0f  &  %6.0f  &',...
        ade,size(XYWch,1),size(XYWPO,1),size(XYWPI,1))

    cpus=[cpus; log_aver_cpu];

end


% D. Statistics

fprintf('\n \n \t             Cputimes \n ')
fprintf('\n \t | ade |    ch    |   sgPO   |   sgPI   |')
fprintf('\n \t .................................... ...')

for k=1:length(adeV)
    fprintf('\n \t  %2.0f  & %1.0e & %1.0e & %1.0e \\',adeV(k), ...
        log_aver_cpu(k,1),log_aver_cpu(k,2),log_aver_cpu(k,3));
    % fprintf('\n \t | %2.0f  | %1.2e | %1.2e | %1.2e |',adeV(k), ...
    % log_aver_cpu(k,1),log_aver_cpu(k,2),log_aver_cpu(k,3));
end

fprintf('\n \n');

